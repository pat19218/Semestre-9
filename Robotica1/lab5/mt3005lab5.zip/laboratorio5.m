% =========================================================================
% MT3005 - LABORATORIO 5: Cinem�tica Directa de Manipuladores Seriales
% -------------------------------------------------------------------------
% Ver las instrucciones en la gu�a adjunta
% =========================================================================
%% Inciso 2.
% Dimensiones del robot
d1 = ;
a1 = ;
alpha1 = ;
offset1 = ;

d2 = ;
a2 = ;
alpha2 = ;
offset2 = ;

d3 = ;
a3 = ;
alpha3 = ;
offset3 = ;

d4 = ;
a4 = ;
alpha4 = ;
offset4 = ;

d5 = ;
a5 = ;
alpha5 = ;
offset5 = ;

d6 = ;
a6 = ;
alpha6 = ;
offset6 = ;

d7 = ;
a7 = ;
alpha7 = ;
offset7 = ;

% Definici�n del robot
J1 = ;
J2 = ;
J3 = ;
J4 = ;
J5 = ;
J6 = ;
J7 = ;

sawyer = SerialLink([J1, J2, J3, J4, J5, J6, J7], 'name', 'SAWYER')

%% Inciso 3.
q0 = ;

%% Inciso 4. 
q1 = ;

%% Inciso 5.
t1 = ;
theta1 = ;
