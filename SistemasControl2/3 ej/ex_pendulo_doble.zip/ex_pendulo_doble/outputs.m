function h = outputs(x, u)
    h = x;
end